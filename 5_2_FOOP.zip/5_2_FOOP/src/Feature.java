
public interface Feature {
	public String getFeature();
	public void setFeature(String feature);
}

