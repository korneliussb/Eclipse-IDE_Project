
public interface Chassis {

	public final String chassis = "Chassis";
	public Chassis getChassisType();
	public void setChassisType(String vehicleChassis);

}
